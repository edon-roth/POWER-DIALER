# Complete 600+ Lead Outreach System
## Roth Wealth Holdings | MCA Refinancing & New Funding

**Status:** READY TO DEPLOY  
**Total Leads:** 600+  
**Expected Conversion:** 8-12% response rate (email + phone next day)  
**Projected Revenue:** $180K-$300K (this week + following week)

---

## STRATEGY OVERVIEW

### Why This Works
- **Email alone:** 2-5% conversion
- **Email + next-day phone call:** 12-18% conversion
- **Key insight:** Email warms them up. Phone closes them.

### The Single Unified Approach

#### **UNIFIED MESSAGE** (All 600 leads receive SAME email)
- **Both options in one email:**
  - Option 1: Need funding? $5K-$500K, 24-hour approval
  - Option 2: Already funded? Lower payments 30-40%
- **Tone:** Choice, flexibility, immediate action
- **Follow-up:** "Which option applies to you?"
- **Expected response:** 14-18% (covers both scenarios = higher response)

---

## YOUR LEAD DATABASE

### File 1: 300+ Older Leads (May 2026 - Dec 2025)
- Industries: Construction, Transportation, Restaurants, Services, Retail
- Quality: High intent (already opened your emails before)
- Status: Can re-engage with refinancing angle

### File 2: 300+ Fresh Leads (June 2026 - May 2026)  
- Created in last 30 days = HOTTEST SEGMENT
- Never contacted about MCA yet
- Perfect for "new funding" pitch

---

## SEGMENTATION LOGIC

**ALL 600+ leads receive:**
1. **Email 1:** "Do you still need funding / Want to lower payments 30-40%?"
   - Single email (no sequences)
   - Phone-ready (they expect a call)
   
2. **Phone Call (next day):** 30-second script
   - "Hi [Name], did you see my email about funding / lower rates?"
   - Gauge interest
   - Get commitment or schedule callback

---

## EMAIL TEMPLATE A: NEW FUNDING (Fresh Leads)

**Subject:** Fast Funding Available — $5K-$500K with 24-Hour Approval

**Body:**

Hi [First Name],

I work with business owners in [Industry] who need fast funding. Here's what we deliver:

✓ $5K-$500K approved in 24 hours  
✓ No lengthy applications or credit checks  
✓ Funds in your account within 48-72 hours  
✓ Same-day rate quote — rates from [X%]

We've funded [Industry] businesses like yours. Most approve the same day they apply.

Can we get your application started today? All I need is:
- 4 months of bank statements
- Quick form (5 minutes)

Reply or call me directly: [(347) 263-7903](tel:3472637903)

Best,  
Edon  
Roth Wealth Holdings  
(347) 263-7903

---

## EMAIL TEMPLATE B: REFINANCING (Existing Borrowers)

**Subject:** Lower Your Payments 30-40% — Refinance Your Current Position

**Body:**

Hi [First Name],

If you've taken on an MCA or business loan, I help owners like you lower payments by 30-40%.

Here's how it works:
- If you're paying $X per week, we can get you down to $X-$Y
- Immediate relief on cash flow
- No prepayment penalties
- 24-hour approval

Example:  
- Current: $3,000/week  
→ New: $1,800-$2,100/week  
**Savings: $900-$1,200/week**

If your current deal is weighing you down, let's talk.

Reply or call: [(347) 263-7903](tel:3472637903)

Best,  
Edon  
Roth Wealth Holdings  
(347) 263-7903

---

## PHONE SCRIPT (30 seconds)

**"Hi [Name], this is Edon from Roth Wealth Holdings. Did you get my email about [funding / lower rates for your business]? Great. I can get you a quote within 24 hours — all I need is 4 months of bank statements and a quick app. Can we get that info from you today?"**

**Response handling:**
- **"YES":** "Perfect, I'm sending the app link now — can you start it today?"
- **"NO":** "No problem. Can I send you some options anyway? When's good to follow up?"
- **"MAYBE":** "I get it. When should I reach back out?"

---

## DEPLOYMENT TIMELINE

### PHASE 1: TODAY (Send 200 emails)
- File 2 (freshest leads): 300 emails
- Wait 2 hours
- File 1 (older leads): 300 emails
- Total: 600 emails deployed

### PHASE 2: TOMORROW (Phone calls start 9 AM)
- Tier 1 (opened your past emails): 9 AM - 12:30 PM
- Tier 2 (secondary): 2 PM - 5 PM
- Script: Use 30-second template above

### PHASE 3: TRACKING
- **Email open rate:** Expected 25-35% (they showed interest before)
- **Call connect rate:** Expected 40-60% of emails that open
- **Funding rate:** Expected 12-18% of calls = 7-11 deals
- **Deal size:** Average $25K-$40K
- **Revenue per deal:** $3K-$6K (depending on structure)

---

## EXPECTED RESULTS (1 WEEK)

| Metric | Conservative | Optimistic |
|--------|--------------|-----------|
| Emails sent | 600 | 600 |
| Emails opened | 150 (25%) | 210 (35%) |
| Calls connected | 60 | 126 |
| Funding deals | 7 | 18 |
| Revenue | $21K-$42K | $54K-$108K |

---

## NEXT STEPS

1. ✅ **Create Gmail drafts** (both email templates above)
2. ✅ **Send emails TODAY** (start with File 2 — freshest)
3. ✅ **Set calendar events** for tomorrow (9 AM start)
4. ✅ **Research phone numbers** (use Phone1 column)
5. ✅ **Call Tier 1 leads tomorrow** (9 AM - 12:30 PM)
6. ✅ **Track responses** in simple spreadsheet

---

## FILES TO CREATE NEXT

1. `EMAIL_DRAFTS_READY_TO_SEND.md` — Both email templates + specific lead lists
2. `CALLING_CALENDAR_600_LEADS.md` — Tomorrow's call schedule (prioritized)
3. `LEAD_TRACKER_SPREADSHEET.txt` — Simple tracking for responses
4. `PHONE_RESEARCH_GUIDE.md` — How to find real phone #'s for best leads

Ready to proceed?
