# ULTRA SIMPLE SENDING SYSTEM

## TODAY (RIGHT NOW)

### Step 1: Send 7 Emails
Go to Gmail **Drafts** folder.

Search for "Stage 1 Initial Contact"

You'll see 7 emails. Send them in this order:

1. **CK FASHION - Stage 1 Initial Contact** → Send
2. **PATRICK CARTER - Stage 1 Initial Contact** → Send
3. **A.F. - Stage 1 Initial Contact** → Send
4. **CARLOS REED - Stage 1 Initial Contact** → Send
5. **MARTIN KARLESA - Stage 1 Initial Contact** → Send
6. **DUSTIN - Stage 1 Initial Contact** → Send
7. **CAREY - Stage 1 Initial Contact** → Send

**Time needed:** 2 minutes

---

## TOMORROW (JUNE 9)

### Call all 7 people
If they don't reply by tomorrow afternoon, call them.

**Phone script (30 seconds):**
> "Hi [Name], this is Edon from Roth Wealth Holdings. Did you get my email yesterday about funding? Great. So if you're interested, I just need 4 months of bank statements and you'll have rates within 24 hours. Can you send those over?"

---

## THEN WHAT?

**If they reply or say yes:**
- Label the email thread: "Prospects/Replied - Action Needed"
- Send them the application link
- Get their 4 bank statements

**If they say no:**
- Label: "Prospects/Dead - No Response"
- Move on

---

## THAT'S IT

No Stage 2. No Stage 3. No confusion.

Just Stage 1 + Phone Calls = Results

---

## KEY RULES

✅ Only send the "Stage 1 Initial Contact" emails
✅ All 7 today
✅ Call tomorrow if no reply
✅ Label when they reply
✅ Stop overthinking

You're done.
