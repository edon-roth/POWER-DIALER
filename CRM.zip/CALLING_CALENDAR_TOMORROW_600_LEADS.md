# TOMORROW'S CALLING SCHEDULE
## June 9, 2026 | Roth Wealth Holdings

**GOAL:** Convert emails to commitments with same-day phone calls  
**EXPECTED:** 40-60 of 600 leads will have opened email → 5-12 funded deals  
**REVENUE TARGET:** $15K-$72K tomorrow alone

---

## CALLING WINDOWS

### WINDOW 1: 9:00 AM - 12:30 PM (Tier 1 - Hottest Leads)
**Target:** 50-60 calls (30 min per call including breaks)  
**Success rate:** 40-50% connect rate, 12-18% funding rate = 6-10 deals

### WINDOW 2: 2:00 PM - 5:00 PM (Tier 2 - Secondary Leads)  
**Target:** 40-50 calls (callbacks, warm leads)  
**Success rate:** 30-40% connect rate, 8-12% funding rate = 3-5 deals

---

## TIER 1 CALLING LIST (START 9 AM - 12:30 PM)
### These are the HOTTEST leads - prioritize these

**TOP 20 TIER 1 LEADS (FILE 2 - Newest, Most Likely to Answer)**

| # | Time | Business Name | Owner | Phone | Email | Status |
|---|------|--------------|-------|-------|-------|--------|
| 1 | 9:00 | Nk Marketing LLC | Naomi Kendagor | 6365785360 | nkmarketingelc@gmail.com | ☐ Called |
| 2 | 9:30 | S Williams & Associates | Sylvester Williams | 8323645999 | sjwilliamsjr05@aol.com | ☐ Called |
| 3 | 10:00 | Carmelan Limo Service LLC | Freddy Mago | 7724057755 | carmelanlimoservice@gmail.com | ☐ Called |
| 4 | 10:30 | Pinnacle Motor Sport Sales | Leonard Mason | 4048861851 | leonardmason908@gmail.com | ☐ Called |
| 5 | 11:00 | Despard Analytics | Thomas Despard | 7703093471 | val_despard@yahoo.com | ☐ Called |
| 6 | 11:30 | RTM Logistics Solutions | Daniel Vogel | 3235748630 | dvogel06@gmail.com | ☐ Called |
| 7 | 12:00 | Trailer Sources Manufacturer | John Hill | 3865901214 | jsullivan128@yahoo.com | ☐ Called |
| 8 | 12:30 | Elevate Top Solutions LLC | Connor Motte | 5155288928 | nmotte@yahoo.com | ☐ Called |
| 9 | 1:00 PM | T G Auto Repair LLC | Tataw Glory | 8044903627 | nahglory@gmail.com | ☐ Called |
| 10 | 1:30 PM | Lawrence Motorsports INC | William Lawrence | 5135325322 | lawrencemotorsports@msn.com | ☐ Called |
| 11 | 2:00 | KT Fab INC | Kenneth Tull | 8634430029 | wardpooh7@aol.com | ☐ Called |
| 12 | 2:30 | Impact Innovations Systems | Jae Lim | 7034986765 | jlim@iis-consulting.com | ☐ Called |
| 13 | 3:00 | Best of Safety Services INC | William Colon | 9177015905 | wcolon@cs.com | ☐ Called |
| 14 | 3:30 | Lavender Healing LLC | Tiana Lavender | 2404798526 | tianalavender@myspecialdentist.com | ☐ Called |
| 15 | 4:00 | The Patriot Bar & Grill | Tom Lara | 7603715353 | stevep102@yahoo.com | ☐ Called |
| 16 | 4:30 | Lavish Royalty Home Care | Kaeisha Murdock | 5749711610 | kaeisha123456@gmail.com | ☐ Called |
| 17 | 5:00 | West End Grille | Tammy Straughn | 7242909912 | tlslaw12@yahoo.com | ☐ Called |
| 18 | 5:30 | Rueppell INC | Darin Rueppell | 2532978040 | darin@builderplans.com | ☐ Called |
| 19 | 6:00 | Onpoint Moving Services LLC | Paul Rogers | 8134423001 | pauljrogers5@gmail.com | ☐ Called |
| 20 | 6:30 | 5 Star Medical LLC | Clifton Hinds | 7025814572 | clifton.hinds@webtv.net | ☐ Called |

[**Continue with remaining File 2 leads...**]

---

## PHONE SCRIPT - 30 SECONDS

**OPENING:**
> "Hi [FIRST_NAME], this is Edon from Roth Wealth Holdings. Did you get my email about fast funding or lower payments?"

**RESPOND BASED ON THEIR SITUATION:**

**IF: "I don't need funding right now"**
> "Perfect. Then let me ask — if you took on an MCA or business loan in the past, can we lower that 30-40%? That's what I was mentioning in the email."

**IF: "I'm already funded / Have a loan"**
> "Great. So we can lower your payments 30-40% — save you $900-$1,200 a week depending on your deal. All I need is 4 months of bank statements. Can we get that submitted today?"

**IF: "I need funding"**
> "Perfect. We can get you $5K-$500K approved in 24 hours. Same thing — 4 months of bank statements, quick app. Can I send you the link now?"

**IF: "Tell me more"**
> "Sure. Quick version: If you need cash, we fund fast. If you already have a deal, we lower your payments. Either way, send me your bank statements and I'll show you exact numbers in 24 hours."

**GOAL:** Get 1 of 3:
1. ✅ **Bank statements + app commitment** (high intent)
2. ✅ **Email link sent + follow-up time** (medium intent)
3. ✅ **Callback scheduled** (low intent - don't waste time)

---

## RESPONSE TRACKING

### DURING CALL - Mark One:

**☐ NO ANSWER** → Try Phone2 / Phone3 → Log "Left voicemail" + time

**☐ INTERESTED - SENT APP** → Log "App sent [time]" + follow up in 2 hours

**☐ INTERESTED - CALLBACK** → Log "Callback [date/time]" + set alarm

**☐ NOT INTERESTED** → Log "No interest" → Move on (don't push)

---

## WHAT TO SAY WHEN THEY SAY...

### "I don't need funding right now"
> "I get it. If things change or cash flow gets tight, I'm literally one call away. Can I check back in 2 weeks?"

### "I'm already working with someone"
> "No problem. If that deal doesn't work out or rates change, I've got better options. Keep my number?"

### "What's the catch?"
> "No catch. We lend to [INDUSTRY], you use the money, you pay back from daily/weekly sales. Rates are [X%]. No hidden fees. That's it."

### "How long does it take?"
> "24-hour approval, 48-72 hours to your account. Fastest in the industry."

### "What's the interest rate?"
> "Depends on your cash flow and use. For [INDUSTRY], typical rates are 2.2% to 4.5%. I can give you exact rate once I see your bank statements."

---

## TIER 2 CALLING LIST (2:00 PM - 5:00 PM)
### FILE 1 Leads (Older = Already opened past emails = WARM)

**TOP 20 FILE 1 LEADS - Secondary Priority**

| # | Time | Business Name | Owner | Phone | Email |
|---|------|--------------|-------|-------|-------|
| 1 | 2:00 | American Plumbing Heating & Cooling | Jonathan Dean | 9419287702 | jdean@deanphc.com |
| 2 | 2:30 | First Leaf Construction | Jeremy Holliday | 4802347763 | hollidayskids123@gmail.com |
| 3 | 3:00 | Hcj Helping Hands | Ernilyn Bosco | 3019197329 | ernilynbosco@aol.com |
| 4 | 3:30 | Lcl Farms | Leslie Lindner | 3195243455 | lclfarmsinc@gmail.com |
| 5 | 4:00 | Digz Volleyball | Paul Nagel | 6053664835 | paulnagel@msn.com |
| 6 | 4:30 | Starpower Exteriors INC | Evangelina Romero | 4026774090 | minhtri301187@gmail.com |
| 7 | 5:00 | Very Best Motors LLC | Darrell Stanfield | 2489097894 | darrellstanfield7@gmail.com |
| 8 | 5:30 | Ready 2 Fix INC | Kenneth Wilson | 4047540447 | kenw0823@yahoo.com |
| 9 | 6:00 | Bill Fielding Carpenter | William Fielding | 6037072278 | wfielding@comcast.net |
| 10 | 6:30 | Rip Productions LLC | Alexander Jarrett | 7027157795 | alex@rip-productions.co.uk |
| 11 | 7:00 | Smsbiotech | Abdulakader Rahmo | 6572033030 | a.rahmo@gmail.com |
| 12 | 7:30 | Exalted Funeral Press | Cristin Kelley | 4073421849 | skkid121@hotmail.com |
| 13 | 8:00 | Jg Gagnon & Sons Excavation | Gerald Gagnon | 6038649903 | jg@jgexcavation.com |
| 14 | 8:30 | Springbrook Grain Farms | Mark Johnson | 7152200307 | mark.johnson@qwest.net |
| 15 | 9:00 | PAIVA Enterprises LLC | Edison Paiva | 6176255559 | paivajr@yahoo.com |
| 16 | 9:30 | Performance Auto Engines | James Burek | 9154495903 | jim.burek@aol.com |
| 17 | 10:00 | Gray Dairy Queen INC | Robert Carver | 4239156735 | tenngirl92@yahoo.com |
| 18 | 10:30 | Leonards Electric LLC | Terry Christian | 3047446757 | tang43@yahoo.com |
| 19 | 11:00 | Katy Kids Shuttle | Shenquilla Allen | 8327626093 | info@katykidsshuttle.com |
| 20 | 11:30 | Roanoke River Tree Harvesters | Kimberly Wallace | 2525329592 | kgwallace8@yahoo.com |

[**Continue with remaining File 1 leads...**]

---

## DAILY TRACKING SHEET

**Template for tracking all calls:**

```
DATE: June 9, 2026

MORNING SESSION (9 AM - 12:30 PM):
├─ Calls attempted: ___
├─ Calls connected: ___  
├─ Apps sent: ___
├─ Callbacks scheduled: ___
├─ Rejections: ___
└─ Deals funded: ___

AFTERNOON SESSION (2 PM - 5 PM):
├─ Calls attempted: ___
├─ Calls connected: ___
├─ Apps sent: ___
├─ Callbacks scheduled: ___
├─ Rejections: ___
└─ Deals funded: ___

TOTAL FOR DAY:
├─ Total calls: ___
├─ Total funded: ___ deals
├─ Revenue generated: $___
└─ Follow-ups needed: ___
```

---

## SUCCESS TARGETS

### MORNING (9 AM - 12:30 PM)
- **60 calls attempted**
- **24 connects (40%)**
- **4-6 apps sent (17-25%)**
- **2-3 deals funded (50% of apps)**
- **Target revenue: $6K-$18K**

### AFTERNOON (2 PM - 5 PM)
- **50 calls attempted**
- **20 connects (40%)**
- **3-4 apps sent (15-20%)**
- **1-2 deals funded (50% of apps)**
- **Target revenue: $3K-$12K**

### TOTAL DAY
- **110 calls**
- **44 connects**
- **7-10 apps sent**
- **3-5 deals funded**
- **$9K-$30K revenue**

---

## NOTES FOR SUCCESS

✅ **Use Phone1 first** — most recent contact  
✅ **If no answer, try Phone2/3** — different number  
✅ **Leave brief voicemail:** "Hi [Name], this is Edon from Roth Wealth Holdings about your funding question. Call me back at [347-263-7903] when you get a chance."  
✅ **Track EVERYTHING** — even rejections show pattern  
✅ **Be friendly, not pushy** — "no's" are just "not now's"  
✅ **Keep script flexible** — these are real people, not robots  
✅ **End every call with a next step** — no dangling conversations  

---

## TOMORROW'S GOAL

**By EOD June 9:**
- 600 emails sent ✅
- 110+ calls placed
- 3-5 funded deals
- $9K-$30K revenue
- All callbacks scheduled for this week

**You are deployment ready.**
