# POWER DIALER - Quick Start Guide

**100% Free Google Voice Auto-Queue System**

---

## WHAT THIS DOES

✅ **One-Click Calling** — Press CALL button → Google Voice opens with number
✅ **Auto-Queue** — After logging call, automatically shows next lead
✅ **Call Timer** — Tracks how long each call takes
✅ **Quick Logging** — Select outcome → "Next Call" button
✅ **Live Stats** — Calls today, apps sent, revenue tracking
✅ **Keyboard Shortcuts** — SPACEBAR to call, Arrow keys to navigate

---

## THE FLOW (SUPER SIMPLE)

### 1️⃣ CALL
- See lead name, email, phone
- Click **CALL NOW** (or press SPACEBAR)
- Google Voice opens
- You make the call
- When done, hang up

### 2️⃣ LOG
- Portal auto-shows "How did call go?" dialog
- Select outcome:
  - ✓ App Sent
  - 💬 Interested
  - 📞 Called (need follow-up)
  - 📱 No Answer
  - ❌ Not Interested
- (Optional) Enter deal amount if they're funding
- Click **Next Call** (or press RIGHT ARROW)

### 3️⃣ NEXT LEAD
- **AUTOMATICALLY shows next lead**
- Go back to step 1
- Repeat all day

---

## KEYBOARD SHORTCUTS (Even Faster)

| Shortcut | Action |
|----------|--------|
| **SPACEBAR** | Start call on current lead |
| **RIGHT ARROW** (in log dialog) | Submit call & go to next lead |
| **LEFT ARROW** (in log dialog) | Skip logging & go to next lead |

---

## DEPLOY (Same 5 Minutes)

1. Create GitHub account (if needed) → https://github.com/signup
2. Create new repo → https://github.com/new
   - Name: `power-dialer`
   - Public
   - Add README
3. Upload `power-dialer.html`
4. Go Settings → Pages → Enable GitHub Pages
5. Your live URL: `https://YOUR-USERNAME.github.io/power-dialer/`

---

## TOMORROW AT 9 AM

1. **Open your dialer:** https://YOUR-USERNAME.github.io/power-dialer/
2. **See current lead** (highest score first = most likely to fund)
3. **Press SPACEBAR** (or click CALL NOW)
4. **Google Voice opens** with phone number pre-filled
5. **Make the call**
6. **Hang up when done**
7. **Portal pops up: "How did call go?"**
8. **Select outcome** (app sent / interested / no answer / etc)
9. **Press RIGHT ARROW** (or click "Next Call")
10. **AUTOMATICALLY shows next lead**
11. **Press SPACEBAR again**
12. **Repeat**

---

## STATS LIVE UPDATE

**At the top you see:**
- Calls Today (0 → 1 → 2...)
- Apps Sent
- Revenue (if they're funding)
- In Queue (how many leads left)

---

## QUEUE VISIBILITY

**Below the call button:**
- See next 5 leads in queue (ordered by score)
- Know exactly who's coming up

---

## OPTIONAL: DEAL LOGGING

If a lead is ready to fund:
1. During call logging, enter **Deal Amount ($)**
2. System auto-calculates your commission
3. Revenue updates instantly

---

## WHY THIS IS FAST

❌ **Old way:** Click call → Google Voice → Make call → Come back → Click log → Select outcome → Find next lead → Repeat (slow)

✅ **Power Dialer:** Spacebar → Call → Log → Next Lead auto-loaded (fast)

**You can do 15-20 calls/hour** instead of 10-12.

---

## YOUR DATA

- All tracked in your browser
- Export anytime
- No cloud, no privacy issues
- 100% your data

---

## NOTES

- First lead has highest score (most likely to convert)
- Leads sorted by conversion likelihood
- Skip button if you can't reach someone
- Skip logging if too busy (come back later)
- Reopen dialer to see stats update

---

**START CALLING. WATCH REVENUE GROW.**

🚀 Tomorrow 9 AM, you'll be dialing fast.
