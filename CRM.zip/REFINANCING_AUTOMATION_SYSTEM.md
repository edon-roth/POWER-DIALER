AUTOMATED REFINANCING OUTREACH SYSTEM
=====================================

**GOAL:** Reach out to existing customers to refinance at 30-40% lower rates

**YOUR MESSAGE:** "We can potentially lower your current position 30-40%"

---

## SEGMENT STRATEGY: EXISTING CUSTOMERS vs. WARM OPENS

### SEGMENT A: WARM OPENS (23 leads from GMass)
- **Status:** Never funded (prospects)
- **Approach:** "Fast funding available"
- **Rate offer:** Standard rates
- **Timeline:** New deals

### SEGMENT B: LIVE LEADS (Your Google Sheets)
- **Status:** Already funded (existing customers)
- **Approach:** "Refinance at 30-40% lower rates"
- **Rate offer:** Competitive refinancing
- **Timeline:** Consolidate/improve existing deals

---

## REFINANCING EMAIL TEMPLATES

Use these templates and customize with each customer's details from your Sheets.

---

### EMAIL TEMPLATE 1: SOFT APPROACH (Personal Touch)

**Subject:** "[Name], We Can Lower Your Funding Cost 30-40%"

```
Hi [Name],

I was reviewing our portfolio and noticed you've been a great partner with us.

Here's the thing: market conditions have shifted, and we can now offer significantly better rates than what you're currently locked in at.

In fact, we can potentially lower your funding costs by 30-40%.

It would only take a quick call to:
1. Review your current terms
2. Model what refinancing could look like for you
3. If it makes sense, we can close it within 48 hours

Are you open to exploring this? I think you'll like what we can do.

Let me know.

Edon
Roth Wealth Holdings
(347) 263-7903
edon@rothwealthholdings.com
```

---

### EMAIL TEMPLATE 2: AGGRESSIVE APPROACH (Value-Focused)

**Subject:** "30-40% Savings Available - Your Refinance Approval in 24 Hours"

```
Hi [Name],

Quick message: We can save you $[CALCULATED AMOUNT] by refinancing your current position.

Here's what changed:
- Your business has better metrics now than when you originally funded
- Our rates are 30-40% lower than what you locked in
- Refinancing is faster than ever (24-48 hours)

This is a no-brainer if you're paying more than necessary.

Can we schedule a 15-minute call this week to show you the numbers?

I think you'll be surprised at the savings.

Edon
Roth Wealth Holdings
(347) 263-7903
```

---

### EMAIL TEMPLATE 3: FRIENDLY CHECK-IN (Relationship-Based)

**Subject:** "How's Business? Let's Optimize Your Funding"

```
Hi [Name],

Hope business is going well.

I'm reaching out because we just updated our funding programs and can now offer something special to existing partners like you:

**30-40% lower rates than your current position**

If you're interested in optimizing your capital costs, I'd love to show you what refinancing could look like. It typically takes less than a week to close.

No obligation - just a quick conversation to see if it makes sense.

When's good for a quick call?

Best,
Edon
Roth Wealth Holdings
(347) 263-7903
```

---

## PHONE SCRIPT FOR EXISTING CUSTOMERS

Use this when they call back or you call them:

```
"Hi [Name], thanks for getting back to me. 

I'll keep this short: We have rates 30-40% better than what you're currently locked into. 

Based on your deal structure, that could save you [DOLLAR AMOUNT] over the term.

It takes 24-48 hours to close if you're interested.

Are you open to looking at the numbers?"

[If YES → "Perfect, I'll send over a comparison. Can we schedule 15 minutes Thursday to review?"]

[If NO → "No problem. If your situation changes, just reach out."]

[If MAYBE → "Great. When would be a good time this week to connect?"]
```

---

## SPREADSHEET MAPPING (How to Use Your Sheets Data)

Your Google Sheets likely has columns like:

| Name | Email | Phone | Current Rate | Current Amount | Funding Date | Status |
|---|---|---|---|---|---|---|
| John Smith | john@... | 555-1234 | 1.25 | $50,000 | Jan 2024 | Active |
| Jane Doe | jane@... | 555-5678 | 1.30 | $75,000 | Feb 2024 | Active |
| ... | ... | ... | ... | ... | ... | ... |

---

## PERSONALIZATION FORMULA

**Calculate savings for each customer:**

```
Current Payment = Current Amount × Current Rate ÷ Term Length
New Payment = Current Amount × (Current Rate × 0.65) ÷ Term Length
Monthly Savings = Current Payment - New Payment
Total Savings = Monthly Savings × Remaining Months
```

**Example:**
- Current: $50,000 × 1.25 ÷ 12 months = $5,208/month
- New (30% lower): $50,000 × 0.875 ÷ 12 = $3,646/month
- **Monthly savings: $1,562**
- **Total savings (if 6 months left): $9,372**

---

## AUTOMATED WORKFLOW

### STEP 1: SEGMENT YOUR LEADS
**Filter your Sheets to only "Active" customers**

Recommended segmentation:
- **Tier 1:** High-value (funding > $50K) + Active
- **Tier 2:** Medium-value ($10K-$50K) + Active
- **Tier 3:** Lower-value (< $10K) or older customers

### STEP 2: CALCULATE SAVINGS
**For each lead, calculate the dollar savings:**
```
Estimated Monthly Savings = (Current Rate - New Rate) × Remaining Balance ÷ Remaining Months
```

### STEP 3: PERSONALIZE EMAILS
**Use Template 1/2/3 based on relationship:**
- Tier 1 (high-value): Template 2 (aggressive/numbers-focused)
- Tier 2 (medium): Template 1 (soft/personal)
- Tier 3 (lower): Template 3 (friendly check-in)

### STEP 4: SEND EMAILS
**Create Gmail drafts for each segment**

### STEP 5: FOLLOW UP WITH CALLS
**Call in 24-48 hours if no response**

---

## EXPECTED RESPONSE RATES

**Existing customers refinancing:**
- **Email open rate:** 40-50% (they know you)
- **Response rate:** 25-35% (existing relationships matter)
- **Conversion rate:** 60-70% of responses → funded

**Formula:** 
- 100 live leads
- 40 opens
- 10 responses
- 6-7 refunded deals
- **6-7 deals from warm outreach**

---

## TIMELINE FOR REFINANCING

**Day 1:** Email sent
**Day 2:** Call non-respondents
**Day 3:** Model/quote sent to interested parties
**Day 4:** Application submitted
**Day 5-7:** Underwriting + funding

---

## EMAIL DRAFT FORMAT (For Multiple Recipients)

You'll need to send personalized emails to each customer. Here's how:

**Option A: Gmail Individual Drafts**
- Create 1 draft per customer
- Personalize with their name/numbers
- Send one at a time

**Option B: Bulk Send (Better)**
- Create template email
- Use mail merge tool (Gmail has this)
- Or use your Sheets integration to send automatically

---

## SAMPLE TIER 1 EMAIL (High-Value Customer)

```
Subject: $[SAVINGS_AMOUNT] Saved - Refinance Approval in 24 Hours

Hi Michael,

Your current position: $75,000 at 1.30 (locked 8 months ago)

What's changed: We can now offer 1.05 (about 19% better rate)

**What this means for you:**
- Monthly payment drops from $6,458 to $5,468
- You save $990/month
- Total savings: ~$9,900 if you refinance now

We can have you closed within 24 hours.

Are you interested in exploring this?

Edon
```

---

## CRITICAL SUCCESS FACTORS

✅ **Personalization matters MORE with existing customers**
- Use their name (not "Hi there")
- Reference their original deal
- Show actual dollar savings
- Mention timeline

✅ **Speed builds urgency**
- "24-hour approval"
- "Market conditions shifting"
- "Locked in at old rates"

✅ **Relationship leverage**
- "Reward for being a great partner"
- "Exclusive opportunity for existing clients"
- "Better rates available now"

---

## YOUR NEXT STEPS

1. **Export your Google Sheets** (or share the key data)
   - Names
   - Emails
   - Phone numbers
   - Current funding amounts
   - Current rates (if available)
   - Remaining term

2. **Tell me how many leads** you have in total

3. **Indicate priority** (want to start with Tier 1 only or all?)

4. **I'll create:**
   - Personalized email for each lead
   - Calculated savings amount for each
   - Calendar events for follow-up calls
   - Tracking system for responses

---

## EXPECTED OUTCOME

**If you execute on all live leads:**
- 25-35% response rate (existing relationship bonus)
- 60-70% conversion of responses
- **6-10 additional funded deals**
- **Additional revenue: $90,000-$150,000**

**Time investment:** 2-3 hours for outreach + calls
**Cost:** $0
**ROI:** Infinite

---

## READY TO SCALE THIS?

Share your Google Sheets data (or paste a few rows as examples) and I'll:
- [x] Calculate exact savings for each customer
- [x] Create personalized emails
- [x] Generate calendar calling schedule
- [x] Build tracking system
- [x] Automate the entire workflow

Just give me your Sheets data and how many leads you're working with.
