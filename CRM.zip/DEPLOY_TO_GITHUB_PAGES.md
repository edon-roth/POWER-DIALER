# Deploy Your MCA Sales Portal to GitHub Pages (FREE)

**Time: 5 minutes**
**Cost: $0 (forever)**
**Tech needed: Just a GitHub account**

---

## STEP 1: Create a GitHub Account (if you don't have one)
1. Go to https://github.com/signup
2. Sign up with your email (edon@rothwealthholdings.com)
3. Verify your email
4. Pick a username (e.g., `edon-roth` or `rothwealthholdings`)

---

## STEP 2: Create a New Repository

1. Go to https://github.com/new
2. **Repository name:** `mca-sales-portal` (or any name you want)
3. **Description:** "MCA Sales Call Tracking Portal"
4. **Public** (important - must be public for GitHub Pages to work)
5. Check "Add a README file"
6. Click **Create Repository**

---

## STEP 3: Upload Your Portal File

1. In your new repo, click **Add file** → **Upload files**
2. Drag and drop `mca-sales-portal.html` (the file we just created)
3. Click **Commit changes**

---

## STEP 4: Enable GitHub Pages

1. Go to **Settings** (top right of repo)
2. Click **Pages** (left sidebar)
3. Under "Source," select **main** branch
4. Click **Save**
5. GitHub will show: "Your site is live at: https://YOUR-USERNAME.github.io/mca-sales-portal/"

---

## STEP 5: Access Your Portal

Your live portal is at:

**https://YOUR-USERNAME.github.io/mca-sales-portal/**

Example: If your username is `edon-roth`, the URL is:
**https://edon-roth.github.io/mca-sales-portal/**

---

## IMPORTANT NOTES

✅ **Your data is stored locally on YOUR device** - nobody sees it, nobody accesses it. It's saved in your browser's local storage.

✅ **No backend required** - this is completely standalone

✅ **Works on mobile** - open the link on your phone tomorrow and start logging calls

✅ **If you change the file**, just re-upload to update your live portal

✅ **Completely free** - GitHub Pages costs $0

---

## HOW TO USE TOMORROW

1. Open your portal URL on your phone
2. Click **Log Call** button
3. Enter the email from your list
4. Select the outcome (App sent, Interested, No answer, etc.)
5. Click **Log Call**
6. The dashboard updates instantly
7. Your data is automatically saved

---

## CUSTOM DOMAIN (Optional - also FREE)

Want your own domain like `mca.rothwealthholdings.com`?

1. Buy a domain from **Namecheap** ($0.99) or similar
2. In your GitHub repo, go **Settings → Pages**
3. Add your custom domain
4. Follow DNS instructions
5. Done

---

## QUESTIONS?

Everything is stored in your browser locally. No cloud, no servers, no monthly fees. Just you and your 524 leads ready to call tomorrow at 9 AM.

**You're ready to go.**
