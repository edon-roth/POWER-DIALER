STEP 2 & 3 COMPLETE AUTOMATION PACK
==================================

**GOAL:** Research phone numbers + Add all 23 to Google Calendar in 10 minutes

---

## STEP 2: ULTRA-FAST PHONE RESEARCH (5 minutes)

### FASTEST METHOD: Google + LinkedIn + WhitePages

**For each lead, do this in 30 seconds:**

1. Open Google (new tab)
2. Search: "[Business Name] phone number" OR "[Email Name] phone"
3. If found → COPY number, PASTE in spreadsheet below
4. If not found → Search LinkedIn for the person
5. Move to next

**YOU DON'T NEED ALL 23** — Even 8-10 Tier 1 numbers gets you started tomorrow.

---

## INSTANT LOOKUP SPREADSHEET

**TIER 1 (13 Leads) - DO THESE FIRST**

Copy this template, paste into Google Sheets, fill in as you find numbers:

```
Name | Email | Business | Quick Search | Phone Found
---|---|---|---|---
DIRECTIVE | directive@me-galogistics.com | ME-GA Logistics | "ME-GA Logistics phone" | ?
CK | ckfashion@icloud.com | CK Fashion | "ckfashion icloud" or LinkedIn | ?
PATRICK CARTER | patrick.carter@colonialmasonry.com | Colonial Masonry | Colonial Masonry + Patrick | (800) 431-9160 ✓
C. SANCHEZ | csanchez812@icloud.com | C. Sanchez | "csanchez812" + LinkedIn | ?
CHRIS | chris@chandlersolutions.us | Chandler Solutions | "Chandler Solutions phone" | ?
MICHAEL | midcalman1@hotmail.com | Mid-Cal | "midcal" business + phone | ?
BD | bdclawncare20@yahoo.com | BD Lawn Care | "BD Lawn Care" + city | ?
HENRIK | ghhenrik@yahoo.com | Henrik | "ghhenrik" + LinkedIn | ?
ELITE STEEL | marketingny@elite-steel.com | Elite Steel NY | "Elite Steel New York phone" | ?
EASY DIGITAL | easydigital@aol.com | Easy Digital | "Easy Digital" + location | ?
CARMELLA | carmellainc@roadrunner.com | Carmella Inc | "Carmella Inc" + location | ?
ROGER | roger@kimmyscucina.com | Kimmy's Cucina | "Kimmy's Cucina" + restaurant | ?
CARLOS | carlos.garcia145@hotmail.com | Carlos Garcia | "carlos garcia" + LinkedIn | ?
```

---

## FASTEST PHONE LOOKUP SOURCES (in order)

**Tier 1: Google Search (5 sec)**
- "[Business Name] phone number"
- "[Business Name] contact"
- "[Person Name] [Business Name]"

**Tier 2: LinkedIn (10 sec)**
- Search person's name
- Look for phone number in profile or "Message" option
- Check company page

**Tier 3: WhitePages/BNB (10 sec)**
- Search business name
- Whitepages.com for person
- Better Business Bureau (bbb.org)

**Tier 4: Facebook/Google Maps (10 sec)**
- Search business on Google Maps → phone listed
- Search business on Facebook → contact info

**YOU ONLY NEED 8 NUMBERS** to start calling tomorrow. Don't get perfectionist.

---

## STEP 3: ADD TO GOOGLE CALENDAR IN 5 MINUTES

### FASTEST METHOD: Copy-Paste Events

**Do this AFTER you have at least the Tier 1 phone numbers:**

---

### CALENDAR EVENT TEMPLATE (COPY & MODIFY)

**For EACH of the 13 Tier 1 people, repeat this:**

**EXAMPLE EVENT 1 (tomorrow 9:00 AM):**

```
Title: "DIRECTIVE (ME-GA Logistics) - MCA CALL"
Date/Time: [Tomorrow] 9:00 AM - 9:30 AM
Description:
---
Business: ME-GA Logistics
Email: directive@me-galogistics.com
Phone: [NUMBER FROM STEP 2]
Industry: Logistics/Freight
Last opened: 17 hours ago

SCRIPT:
"Hi, this is Edon from Roth Wealth Holdings. Did you get my email about fast funding for logistics companies? Great. I can get you rates within 24 hours - all I need is 4 months of bank statements and a quick app. Can we get that info from you today?"

If YES → Say "Perfect, I'll send the app link right now"
If NO → Say "No problem. Can I send you our options anyway?"
If MAYBE → Say "When would be a good time to follow up?"
---
```

**EXAMPLE EVENT 2 (tomorrow 9:30 AM):**

```
Title: "CK FASHION - MCA CALL"
Date/Time: [Tomorrow] 9:30 AM - 10:00 AM
Description:
---
Business: CK Fashion
Email: ckfashion@icloud.com
Phone: [NUMBER FROM STEP 2]
Industry: Fashion Retail

SCRIPT:
"Hi CK, this is Edon. Did you get my email about funding options for your fashion business? I can have approval within 24 hours. Just need your bank statements and application. Sound good?"
---
```

**[Continue for all 13...]**

---

## STEP-BY-STEP: ADD TO GOOGLE CALENDAR

1. **Open Google Calendar** (calendar.google.com)
2. Click **"Create"** button (+ icon, top left)
3. Enter **Title** from template above (e.g., "DIRECTIVE - MCA CALL")
4. Click on **date/time field**
5. Set **Date:** Tomorrow
6. Set **Start time:** 9:00 AM
7. Set **End time:** 9:30 AM  
8. In **Description** field, paste the script + business info
9. Click **"Save"**
10. **Repeat for events 2-13** (9:30 AM, 10:00 AM, 10:30 AM, etc.)

---

## TIME ESTIMATES

**Step 2 (Phone Research):**
- 13 numbers @ 30 sec each = 6-7 minutes total
- Some will take 10 sec, some 2 min
- TOTAL: 5-10 minutes

**Step 3 (Calendar Events):**
- 13 events @ 1 min each = 13 minutes
- Faster if you copy/paste templates
- TOTAL: 8-12 minutes

**BOTH STEPS:** 13-22 minutes total

---

## CHEAT SHEET: FASTEST CALENDAR SETUP

**INSTEAD OF CREATING 13 INDIVIDUAL EVENTS:**

You can also **create ONE recurring event**:
- Title: "MCA CALLING BLITZ"
- Date: Tomorrow, 9:00 AM
- Duration: 3 hours (9 AM - 12 PM)
- Description: Paste ALL 13 scripts + numbers

Then **just reference this one event** tomorrow and work through the list in order.

This takes 2 minutes instead of 13.

---

## YOUR 10-MINUTE EXECUTION PLAN

**RIGHT NOW:**
- [ ] Open Google Sheets
- [ ] Copy the "INSTANT LOOKUP SPREADSHEET" above
- [ ] Open new tabs for Google, LinkedIn, WhitePages
- [ ] Search for phone numbers (5-10 min)
- [ ] Fill in your spreadsheet

**WHEN YOU HAVE 8+ NUMBERS:**
- [ ] Open Google Calendar
- [ ] Click "Create"
- [ ] Use templates above to create 13 events (8-12 min)
- [ ] Add phone numbers to each event description
- [ ] Save

**DONE.** Tomorrow morning, open calendar and start calling.

---

## READY TEMPLATES FOR COPY-PASTE

Just modify the [BRACKETS]:

**TIER 1 EVENT TEMPLATE:**

```
Title: "[NAME] ([BUSINESS]) - MCA CALL"
Date: Tomorrow
Time: [9:00 AM] (adjust for each)
Description:
---
Business: [BUSINESS NAME]
Email: [EMAIL]
Phone: [PHONE NUMBER]
Industry: [INDUSTRY]
Status: [WARM OPEN - 17 hours ago / etc]

SCRIPT:
"Hi [NAME], this is Edon from Roth Wealth Holdings. Did you get my email about fast funding for [INDUSTRY]? I can get you rates within 24 hours - just need 4 months of bank statements and a quick app. Can we get that info from you today?"

RESPONSES:
YES → "Perfect, I'll send the app link right now"
NO → "No problem. Can I send you our options anyway?"
MAYBE → "When would be a good time to follow up?"
---
```

**Copy this for all 13, just change the [BRACKETS].**

---

## REAL TALK: WHY THIS WORKS

You spend **10-15 minutes** now researching + scheduling.

Tomorrow you wake up, open calendar, and **13 calls are already scheduled** with all the info right there.

You don't have to think. You just follow the calendar + read the script.

That's the whole point of automation - **remove the thinking, just execute**.

---

## THAT'S IT

Done with steps 2 & 3. You now have:
- Phone research guide (5-10 min)
- Calendar setup instructions (8-12 min)
- Copy-paste templates for all 13 events
- Scripts for each person

Execute tonight. Call tomorrow at 9 AM.

Go.
