# EMAILS TO DELETE FROM SENT FOLDER

## Instructions:
1. Go to Gmail **Sent** folder
2. Search for each subject line below
3. Click the checkbox next to it
4. Click Delete
5. Repeat for all 11 emails

---

## DELETE THESE 11 EMAILS:

### ckfashion@icloud.com (DELETE 2)
- [ ] Subject: "Following Up - Funding Options"
- [ ] Subject: "Funding Options - Final Note"

### patrick.carter@colonialmasonry.com (DELETE 2)
- [ ] Subject: "Re: Funding Options"
- [ ] Subject: "Final Note - Funding Options"

### afkn@optonline.net (DELETE 1)
- [ ] Subject: "Funding Follow-Up"

### carlosreed618@outlook.com (DELETE 1)
- [ ] Subject: "Funding Follow-Up"

### martinkarlesa@icloud.com (DELETE 1)
- [ ] Subject: "Funding Follow-Up"

### dustin@ironclad.group (DELETE 2)
- [ ] Subject: "Funding Options Available"
- [ ] Subject: "Funding Follow-Up"

### carey@interactpeds.com (DELETE 2)
- [ ] Subject: "Business Funding Options"
- [ ] Subject: "Funding Inquiry"

---

## KEEP NOTHING FROM TODAY

Once deleted, your sent folder for these 7 people will be clean.

---

## AFTER YOU DELETE:

Come back and I'll give you:
- **ONE** email per person (Stage 1 only)
- Clear instructions on when to send
- No confusion, no mixing up stages

Simple system. You'll use minimal brain power.
