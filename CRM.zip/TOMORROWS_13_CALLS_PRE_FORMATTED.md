TOMORROW'S CALLING SCHEDULE - PRE-FORMATTED FOR GOOGLE CALENDAR
===============================================================

**DATE:** Tomorrow
**TIME WINDOW:** 9:00 AM - 12:30 PM (3.5 hours for 13 calls)
**FORMAT:** Copy each "EVENT" below into Google Calendar

---

## EVENT 1
```
TITLE: DIRECTIVE (ME-GA Logistics) - MCA CALL
TIME: 9:00 AM - 9:30 AM
DESCRIPTION:
Business: ME-GA Logistics (Logistics/Freight)
Email: directive@me-galogistics.com
Phone: [FILL IN]
Last opened: 17 hours ago (HOTTEST)

SCRIPT: "Hi, this is Edon from Roth Wealth Holdings. Did you get my email about fast funding for logistics companies? Great. I can get you rates within 24 hours - all I need is 4 months of bank statements and a quick app. Can we get that info from you today?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 2
```
TITLE: CK FASHION - MCA CALL
TIME: 9:30 AM - 10:00 AM
DESCRIPTION:
Business: CK Fashion (Fashion Retail)
Email: ckfashion@icloud.com
Phone: [FILL IN]
Last opened: 17 hours ago (HOTTEST)

SCRIPT: "Hi CK, this is Edon. Did you get my email about funding options for your fashion business? I can have approval within 24 hours. Just need your bank statements and application. Sound good?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 3
```
TITLE: PATRICK CARTER (Colonial Masonry) - MCA CALL
TIME: 10:00 AM - 10:30 AM
DESCRIPTION:
Business: Colonial Masonry (Construction/Masonry)
Email: patrick.carter@colonialmasonry.com
Phone: (800) 431-9160 ✓ ALREADY FOUND
Last opened: 16 hours ago (HOTTEST)

SCRIPT: "Hi Patrick, Edon from Roth Wealth Holdings. Got my email about funding? I can fund masonry companies fast - 24 hours max. Need your last 4 bank statements and application. Can you get those over today?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 4
```
TITLE: C. SANCHEZ - MCA CALL
TIME: 10:30 AM - 11:00 AM
DESCRIPTION:
Business: C. Sanchez (Unknown Industry)
Email: csanchez812@icloud.com
Phone: [FILL IN]
Last opened: 17 hours ago (HOTTEST)

SCRIPT: "Hi, this is Edon from Roth Wealth Holdings. Did you see my email about fast funding? I can get you approved today if you send over 4 months of bank statements. Can you do that?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 5
```
TITLE: CHRIS (Chandler Solutions) - MCA CALL
TIME: 11:00 AM - 11:30 AM
DESCRIPTION:
Business: Chandler Solutions (Consulting/Solutions)
Email: chris@chandlersolutions.us
Phone: [FILL IN]
Last opened: 15 hours ago (HOTTEST)

SCRIPT: "Hi Chris, Edon here. Got my message about funding? I can have rates to you in 24 hours - just need your bank statements. Can we get started today?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 6
```
TITLE: MICHAEL (Mid-Cal) - MCA CALL
TIME: 11:30 AM - 12:00 PM
DESCRIPTION:
Business: Mid-Cal (Unknown Industry)
Email: midcalman1@hotmail.com
Phone: [FILL IN]
Last opened: 5 hours ago (VERY FRESH!)

SCRIPT: "Hi Michael, Edon from Roth Wealth Holdings. Did you get my recent email about fast funding? Perfect timing - I can have you approved within 24 hours. What do you say?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 7
```
TITLE: BD LAWN CARE - MCA CALL
TIME: 12:00 PM - 12:30 PM
DESCRIPTION:
Business: BD Lawn Care (Landscaping/Lawn Care)
Email: bdclawncare20@yahoo.com
Phone: [FILL IN]
Last opened: 12 hours ago (HOTTEST)

SCRIPT: "Hi, this is Edon. You got my email about funding for lawn care companies? I can move fast - 24-hour approval. Just need your statements. Sound good?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

---

## AFTERNOON SESSION (2-5 PM - Continue if needed)

## EVENT 8
```
TITLE: HENRIK - MCA CALL
TIME: 2:00 PM - 2:30 PM
DESCRIPTION:
Business: Henrik (Unknown Industry)
Email: ghhenrik@yahoo.com
Phone: [FILL IN]
Last opened: 12 hours ago

SCRIPT: "Hi Henrik, Edon here from Roth Wealth Holdings. Did you see my email? Fast funding - 24 hours. Need your last 4 bank statements. Ready?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 9
```
TITLE: ELITE STEEL (New York) - MCA CALL
TIME: 2:30 PM - 3:00 PM
DESCRIPTION:
Business: Elite Steel NY (Manufacturing/Steel)
Email: marketingny@elite-steel.com
Phone: [FILL IN]
Last opened: 16 hours ago

SCRIPT: "Hi, this is Edon from Roth Wealth Holdings. I know you got my email about funding for steel/manufacturing. I can have rates within 24 hours. All I need is your bank statements. Can we make that happen today?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 10
```
TITLE: EASY DIGITAL - MCA CALL
TIME: 3:00 PM - 3:30 PM
DESCRIPTION:
Business: Easy Digital (Digital Services/Marketing)
Email: easydigital@aol.com
Phone: [FILL IN]
Last opened: 14 hours ago

SCRIPT: "Hi, Edon from Roth Wealth Holdings. Did my email come through about fast funding? I can approve you within 24 hours - just need 4 bank statements and the app. Ready to move?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 11
```
TITLE: CARMELLA INC - MCA CALL
TIME: 3:30 PM - 4:00 PM
DESCRIPTION:
Business: Carmella Inc (Unknown Industry)
Email: carmellainc@roadrunner.com
Phone: [FILL IN]
Last opened: 14 hours ago

SCRIPT: "Hi Carmella, this is Edon. Did you get my email about funding? I can have you approved today if you send me 4 months of bank statements. Can you do that?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 12
```
TITLE: ROGER (Kimmy's Cucina) - MCA CALL
TIME: 4:00 PM - 4:30 PM
DESCRIPTION:
Business: Kimmy's Cucina (Restaurant/Food & Beverage)
Email: roger@kimmyscucina.com
Phone: [FILL IN]
Last opened: 21 hours ago

SCRIPT: "Hi Roger, Edon from Roth Wealth Holdings. Got my email about restaurant funding? I can have rates within 24 hours for your restaurant. Need your last 4 bank statements. Sound good?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

## EVENT 13
```
TITLE: CARLOS GARCIA - MCA CALL
TIME: 4:30 PM - 5:00 PM
DESCRIPTION:
Business: Carlos Garcia (Unknown Industry)
Email: carlos.garcia145@hotmail.com
Phone: [FILL IN]
Last opened: 18 hours ago

SCRIPT: "Hi Carlos, Edon here. Did you see my email about fast business funding? 24-hour approval - just need your bank statements. Can we get that from you today?"

RESPONSES: YES → "Perfect, app link coming now" | NO → "No problem, can I send options?" | MAYBE → "When should I follow up?"
```

---

## HOW TO USE THIS TOMORROW

1. **9:00 AM:** Open Google Calendar (this document stays open too for reference)
2. **Start with Event 1:** Look at your calendar event for "DIRECTIVE"
3. **Dial the phone number** from the calendar description
4. **Read the script** (it's right there in the description)
5. **Log their response:** YES / NO / MAYBE / VOICEMAIL
6. **Move to next event** (9:30 AM automatically arrives)
7. **Repeat 13 times**

---

## QUICK STATS

- **13 calls** = 3.5 hours total (9 AM - 12:30 PM + afternoon if needed)
- **Per call:** 30 minutes blocked (but actual call = 2-3 min)
- **Expected YES responses:** 3-5 (12-18% conversion)
- **Expected revenue:** $30,000-$45,000 if all 3-4 close

---

## NOTES FOR TOMORROW

- [ ] Have pen/paper ready to take notes
- [ ] Phone on speaker so you can write while talking
- [ ] Calendar open showing next call time
- [ ] This script document bookmarked for quick reference
- [ ] Gmail ready to send applications to anyone who says YES
- [ ] Spreadsheet ready to track YES/NO/MAYBE

**That's all you need.**

Execute tomorrow at 9 AM.
