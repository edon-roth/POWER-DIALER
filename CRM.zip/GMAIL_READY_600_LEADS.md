# GMAIL READY EMAIL DRAFTS
## 600+ Leads | Two Email Templates

---

## DRAFT #1: NEW FUNDING (Freshest Leads - File 2)
### Send to: 300 newest leads (created June 5 - May 7, 2026)

**EMAIL SUBJECT:**  
`Fast Funding Available — $5K-$500K with 24-Hour Approval`

**EMAIL BODY:**

Hi [FIRST_NAME],

I work with business owners in [INDUSTRY] who need fast funding. Here's what we deliver:

✓ $5K-$500K approved in 24 hours  
✓ No lengthy applications or credit checks  
✓ Funds in your account within 48-72 hours  
✓ Same-day rate quote — rates from 2.2%

We've funded [INDUSTRY] businesses like yours. Most approve the same day they apply.

Can we get your application started today? All I need is:
- 4 months of bank statements
- Quick form (5 minutes)

Reply here or call me directly: (347) 263-7903

Best,  
Edon  
Roth Wealth Holdings  
Founder & Direct Lender  
(347) 263-7903  
edon@rothwealthholdings.com

---

### RECIPIENTS - FILE 2 (Newest Leads - Email Template A: NEW FUNDING)

**Send this email to these 300 leads from File 2:**

1. nkmarketingelc@gmail.com (NK Marketing LLC)
2. sjwilliamsjr05@aol.com (S Williams & Associates)
3. carmelanlimoservice@gmail.com (Carmelan Limo Service LLC)
4. leonardmason908@gmail.com (Pinnacle Motor Sport Sales)
5. val_despard@yahoo.com (Despard Analytics)
6. dvogel06@gmail.com (RTM Logistics Solutions)
7. jsullivan128@yahoo.com (Trailer Sources Manufacturer)
8. nmotte@yahoo.com (Elevate Top Solutions LLC)
9. nahglory@gmail.com (T G Auto Repair LLC)
10. lawrencemotorsports@msn.com (Lawrence Motorsports INC)
11. wardpooh7@aol.com (KT Fab INC)
12. jlim@iis-consulting.com (Impact Innovations Systems INC)
13. wcolon@cs.com (Best of Safety Services INC)
14. tianalavender@myspecialdentist.com (Lavender Healing LLC)
15. stevep102@yahoo.com (The Patriot Bar & Grill)
16. kaeisha123456@gmail.com (Lavish Royalty Home Care)
17. tlslaw12@yahoo.com (West End Grille)
18. darin@builderplans.com (Rueppell INC)
19. pauljrogers5@gmail.com (Onpoint Moving Services LLC)
20. clifton.hinds@webtv.net (5 Star Medical LLC)

[Continue with remaining 280 leads from File 2 - all primary emails from column Email1]

---

## DRAFT #2: REFINANCING EXISTING FUNDING (Older Leads - File 1)
### Send to: 300 older leads (created May 7 - Dec 2025)

**EMAIL SUBJECT:**  
`Lower Your Payments 30-40% — Refinance Your Current Position`

**EMAIL BODY:**

Hi [FIRST_NAME],

If you've taken on an MCA or business loan, I help owners like you lower payments by 30-40%.

Here's how it works:
- If you're paying $X per week, we can get you down to $X-$Y
- Immediate relief on cash flow
- No prepayment penalties
- 24-hour approval on new rates

**Real example:**  
Current: $3,000/week  
→ New: $1,800-$2,100/week  
**Savings: $900-$1,200/week**

If your current deal is weighing you down, let's talk. I've helped 100+ owners in [INDUSTRY] cut their weekly obligations in half.

Reply here or call me directly: (347) 263-7903

Best,  
Edon  
Roth Wealth Holdings  
Founder & Direct Lender  
(347) 263-7903  
edon@rothwealthholdings.com

---

### RECIPIENTS - FILE 1 (Older Leads - Email Template B: REFINANCING)

**Send this email to these 300 leads from File 1:**

1. jdean@deanphc.com (American Plumbing Heating & Cooling LLC)
2. hollidayskids123@gmail.com (First Leaf Construction)
3. ernilynbosco@aol.com (Hcj Helping Hands)
4. lclfarmsinc@gmail.com (Lcl Farms)
5. paulnagel@msn.com (Digz Volleyball)
6. minhtri301187@gmail.com (Starpower Exteriors INC)
7. darrellstanfield7@gmail.com (Very Best Motors LLC)
8. kenw0823@yahoo.com (Ready 2 Fix INC DBA Mr Appliance Of Alpharetta)
9. wfielding@comcast.net (William H Fielding III DBA Bill Fielding Carpenter Contractor)
10. alex@rip-productions.co.uk (Rip Productions LLC)
11. a.rahmo@gmail.com (Smsbiotech)
12. skkid121@hotmail.com (Matthew G Kelley Cristin S Kelley DBA Exalted Funeral Press)
13. jg@jgexcavation.com (Jg Gagnon & Sons Excavation LLC)
14. mark.johnson@qwest.net (Springbrook Grain Farms LLC)
15. paivajr@yahoo.com (PAIVA Enterprises LLC)
16. jim.burek@aol.com (Performance Auto Engines)
17. tenngirl92@yahoo.com (Gray Dairy Queen INC)
18. tang43@yahoo.com (Leonards Electric LLC)
19. info@katykidsshuttle.com (Katy Kids Shuttle)
20. kgwallace8@yahoo.com (Roanoke River Tree Harvesters)

[Continue with remaining 280 leads from File 1 - all primary emails from column Email1]

---

## SEND SEQUENCE

### TODAY - 2:00 PM (File 2 - NEW FUNDING - 300 emails)
- Create Gmail draft with Template A
- Add all 300 File 2 Email1 addresses to BCC
- Subject: `Fast Funding Available — $5K-$500K with 24-Hour Approval`
- **ACTION:** Click SEND

### TODAY - 4:00 PM (File 1 - REFINANCING - 300 emails)
- Create Gmail draft with Template B
- Add all 300 File 1 Email1 addresses to BCC
- Subject: `Lower Your Payments 30-40% — Refinance Your Current Position`
- **ACTION:** Click SEND

---

## SUCCESS METRICS

**After sending:**
- Monitor Gmail tracking if enabled (GMass, Cirrus Insight, etc.)
- Expected open rate: 25-35% (these leads already opened your emails)
- Expected response rate: 3-5% (email only)
- **Tomorrow morning:** Start calling those who opened

---

## ALTERNATIVE APPROACH (If you want to customize per lead)

Instead of BCC to all, you could:
1. Use Gmail template variables [FIRST_NAME], [INDUSTRY], [BUSINESS_NAME]
2. Send individually to top 50 leads first (test)
3. Scale to full 600 after optimization

For now: **BCC to all = fastest deployment**

---

## NEXT: CALLING CALENDAR

Once emails are sent, tomorrow at 9:00 AM:
- Call Tier 1: Leads who opened (highest intent)
- Use Phone1 column
- Script: "Hi [Name], did you see my email about [funding/lower rates]?"
- Track: Yes / No / Callback

