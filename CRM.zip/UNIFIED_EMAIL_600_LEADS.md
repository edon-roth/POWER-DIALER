# UNIFIED EMAIL FOR ALL 600 LEADS
## Single Email | Both Options | All Recipients

---

## EMAIL TEMPLATE (Send to ALL 600)

**EMAIL SUBJECT:**  
`Fast Funding Available or Lower Payments 30-40% — Your Choice`

**EMAIL BODY:**

```
Hi [FIRST_NAME],

Two options depending on where you're at:

OPTION 1: Need Funding?
✓ $5K-$500K approved in 24 hours  
✓ No lengthy applications or credit checks  
✓ Funds in your account within 48-72 hours  
✓ Rates from 2.2%

OPTION 2: Already Funded & Struggling?
✓ Lower your current payments 30-40%
✓ Immediate cash flow relief
✓ No prepayment penalties
✓ 24-hour rate quote

Real example:  
Paying $3,000/week?  
→ We can get you to $1,800-$2,100/week  
Savings: $900-$1,200/week

Either way, I can help. All I need is:
- 4 months of bank statements
- 5-minute app

Reply here or call me directly: (347) 263-7903

Best,  
Edon  
Roth Wealth Holdings  
(347) 263-7903  
edon@rothwealthholdings.com
```

---

## ALL 600 RECIPIENTS

### File 1 - 300 Leads (Copy all Email1 addresses below)

jdean@deanphc.com
hollidayskids123@gmail.com
ernilynbosco@aol.com
lclfarmsinc@gmail.com
paulnagel@msn.com
minhtri301187@gmail.com
darrellstanfield7@gmail.com
kenw0823@yahoo.com
wfielding@comcast.net
alex@rip-productions.co.uk
a.rahmo@gmail.com
skkid121@hotmail.com
jg@jgexcavation.com
mark.johnson@qwest.net
paivajr@yahoo.com
jim.burek@aol.com
tenngirl92@yahoo.com
tang43@yahoo.com
info@katykidsshuttle.com
kgwallace8@yahoo.com
unique_flowers@bellsouth.net
wildbill71568@aol.com
nkonen32@gmail.com
hphuonglove@yahoo.com
kc00busa@yahoo.com
cojefferson87@yahoo.com
esdancer@comcast.net
boricua73@ymail.com
brabon73@icloud.com
abryant1026@hotmail.com
dpalmer@hiwaay.net
gatescomed@gmail.com
jviguerias51@yahoo.com
enall0004@kwc.edu
nate.fraser@live.com
yaniradionicio@gmail.com
pngin75@gmail.com
creneesimpson@gmail.com
dominicschoenhofer@hotmail.com
thachthien32@gmail.com
segayet5399@yahoo.com
jmfrow@att.net
47maris@gmail.com
arey.g.7961@gmail.com
blairs55@yahoo.com
marteciakelly@gmail.com
macmurdo_bill@yahoo.com
kelipeklivaresy@ecoutlook.com
eastsidetrk@gmail.com
donnellconstruction@yahoo.com
albertosouzafilho@hotmail.com
jayjaystephens@hotmail.com
csarra@att.net
jevonjr@ymail.com
salallam@gmail.com
expositoarais@yahoo.com
territeach@aol.com
janie.strother@sbcglobal.net
voula.sdrakas@gmail.com
marcoastark@gmail.com
polo_raw13@yahoo.com
kaylacarter091@icloud.com
loricouch30@gmail.com
vpsmasonry@aol.com
scott1009@verizon.net
m34davis@yahoo.com
kiaranbelz@gmail.com
vgarcia23@hotmail.com
chriszerfass@gmail.com
salliemusso@netzero.net
tropicalescapesaz@gmail.com
davidhuff1c@yahoo.com
shad.sullivan@gmail.com
smarkusch96@gmail.com
travishooper71123@gmail.com
arronlongmire@gmail.com
jacobbuss@yahoo.com
flyaseagle213@yahoo.com
bledarlece09@gmail.com
jbruno3832@aol.com
gtavares2124@yahoo.com
cristie.north@bellsouth.net
twofold-ridge-0m@icloud.com
mj6676@yahoo.com
hatfieldjustin9628@gmail.com
yamelviera@yahoo.com
elivey7383@gmail.com
shaunakuehne@gmail.com
dylanras87@gmail.com
ezacarias2@citruscapital.net
thefrenchbee@gmail.com
emlmarkcapital@gmail.com
louisglisson@hotmail.com
eddiedudz@yahoo.com
arysanderson24@gmail.com
munnisa2@gmail.com
bwrobertshaw@gmail.com
guesman@angelfire.com
kdomin@aol.com
bidyutshome@gmail.com
omar.mahmoud1551@gmail.com
anthonykeyes@gmail.com
elmehdi.hazili@gmail.com
vieirajonathan@yahoo.com
flamboyantprettyash@yahoo.com
allibanham@hotmail.com
amishguy@gmail.com
jorgefcova50@gmail.com
bad74cuda@gmail.com
sept101297@hotmail.com
erickolson@yahoo.com
marlon.morgan@gmail.com
info@kobihomecare.com
cludiaalvaro1995@yahoo.com
garygnknight@gmail.com
macedodiego2804@hotmail.com
bellarussa@gmail.com
fandjnezaj@hotmail.com
marioaniceto@gmail.com
jsacco77@hotmail.com
marioaniceto1@gmail.com
mtif628@gmail.com
TYWILD73@GMAIL.COM
isillygee@gmail.com
john@citylightandpower.com
lil_beanie80@yahoo.com
roccptoto0@gmail.com
medwards@cgedwards.com
annainparadise2013@yahoo.com
wbrady1674@aol.com
arrowaranchjb@gmail.com
tributestar@att.net
goldenlocs@aol.com
hockeyjon23@yahoo.com
mckeeac@yahoo.com
psdd15@aol.com
williamrcampbell87@gmail.com
aubrey.jefferson@yahoo.com
fishflyexplorer@gmail.com
elvisistheman@gmail.com
deborah.quaglietta@gmail.com
sfreistadt@yahoo.com
detra.bryant@hotmail.com
sukhpreet.singh@gmail.com
caridadcastro@gmail.com
jason.figurelli@gmail.com
jayvian_holcomb@aol.com
superpainter1962@yahoo.com
alvarezfamily214@gmail.com
opalruffins45@yahoo.com
ahmetsahingedik@gmail.com
jervin0721@yahoo.com
karlitaa26@yahoo.com
greengringo59@yahoo.com
alhaywood@clearchannel.com
wmike@gmail.com
luz.maysonet@gmail.com
xstoleyt@gmail.com
vkdvaryan@yahoo.com
eugenegordon3771@gmail.com
eccabello@gmail.com
victoriaavinson@gmail.com
schriste12@gmail.com

### File 2 - 300 Leads (Copy all Email1 addresses below)

nkmarketingelc@gmail.com
sjwilliamsjr05@aol.com
carmelanlimoservice@gmail.com
leonardmason908@gmail.com
val_despard@yahoo.com
dvogel06@gmail.com
jsullivan128@yahoo.com
nmotte@yahoo.com
nahglory@gmail.com
lawrencemotorsports@msn.com
wardpooh7@aol.com
jlim@iis-consulting.com
wcolon@cs.com
tianalavender@myspecialdentist.com
stevep102@yahoo.com
kaeisha123456@gmail.com
tlslaw12@yahoo.com
darin@builderplans.com
pauljrogers5@gmail.com
clifton.hinds@webtv.net
mscharaga@yahoo.com
azawisza@verizon.net
tjosianna@gmail.com
haase_2009@hotmail.com
bishopaturner@yahoo.com
joan.vollmer@jvprovisionsllc.com
tobinparker@windstream.net
dreamgurl1304@aol.com
pipo2stay@aim.com
dipan.patel@emoryhealthcare.org
kaweezyt@gmail.com
nick.dixon@jdsu.com
kenfees@hotmail.com
lamnguyeen@gmail.com
abond618@gmail.com
douglashartman@hotmail.com
richardkruper@yahoo.com
davidjramos@gmail.com
blancagfamos@yahoo.com
santanahector9010@gmail.com
ashlynconstruction@yahoo.com
weber.lyncee@gmail.com
isaiah.grigg@gmail.com
a.tturskyte@gmail.com
dramagirl4ever1@aol.com
carlecar@verizon.net
rlw0215@gmail.com
kgwallace8@yahoo.com
atenargonzalez81@icloud.com
chad9597@gmail.com
krimprovements@gmail.com
amypoteat@ymail.com
kyriegle@gmail.com
mspinkym@gmail.com
kiet.huynh@gmail.com
eoleiva85@aol.com
mshmuel@aol.com
chopravikas@hotmail.com
amelielim1976@gmail.com
ciera_sparks@yahoo.com
wrghtech@yahoo.com
lima.edgar95@yahoo.com
jonesgr77@comcast.net
atlantiku99@aol.com
jolynn2715@gmail.com
ldemuth1@bellsouth.net
sarah.davis@huschblackwell.com
yandcanderson200@aol.com
mfiki@yahoo.com
cjbianca.corp@gmail.com
monkeymike2@msn.com
whitewaters2@yahoo.com
shaw.sharde1@yahoo.com
brkrajeshkumar@gmail.com
jonpaulh@marshall.usc.edu
chef162003@yahoo.com
kentvgrover@gmail.com
majestichc11@gmail.com
antcam44@gmail.com
torresjoel1812@gmail.com
claudiaolacio@gmail.com
leslie@mcmcompanyinc.com
jstumhofer@gmail.com
chrisjames23323@gmail.com
thomaspingitore@yahoo.com
rabird83@yahoo.com
SSILVER@FLORIDALEGAL.NET
skyemeece@gmail.com
kitkatlove06@gmail.com
dan@pacificservicecenter.com
george.lucas@cableone.net
daylenhernandez80@yahoo.com
widuos1@yahoo.com
luckysandwich@icloud.com
rezk67@gmail.com
shulindajordan05@gmail.com
octavio@apfelbaumind.com
dakota75@hotmail.com
jeremysanders@kcmarriott.com
trustyevents@comcast.net
omerahmed9000@gmail.com
parker@cashlovellstables.com
clallen1967@gmail.com
willwaters1980@yahoo.com
ghwy101@yahoo.com
osancler@hotmail.com
rm.oxo.0@gmail.com
aabibi90@gmail.com
tedhartner@thepcsgroup.net
jkowalski3247@gmail.com
fsblkws@protonmail.com
hommerecords@hotmail.com
experience@cminternationale.com
info@harbisoncollection.com
jbflkeys@webtv.com
rbd0502@yahoo.com
newomi2015@gmail.com
walaaunet@hotmail.com
lena@mdsigi.com
info@abeestudios.com
5888756@mail.ru
quantumsportsbreaks@gmail.com
butcher333@icloud.com
b.tabibian@subway.com
emorales968@gmail.com
adinov9@gmail.com
liviotaveras03@live.com
jkobi@hotmail.com
itiogoto@gmail.com
darnellv1020@hotmail.com
abazner@hotmail.com
eliesamaha68@hotmail.com
markhartre4u@aol.com
smart510cali@gmail.com
gina_belleza@yahoo.com
travis.houseman89@gmail.com
coreyme@yahoo.com
angelbella112@gmail.com
hubcitygranite@live.com
jessesiegel@gmail.com
jhenard31@yahoo.com
alucera@gmail.com
fkh623@yahoo.com
theroyjohnsonjr@gmail.com
monadlrm@yahoo.com
mathew.miller@redcross.org
ricej901@gmail.com
success@gmail.com
ruizbricco@comcast.com
michael.davis7069@gmail.com
lesterchris34@gmail.com
porteranthony14@gmail.com
sam161128@gmail.com
jasmineraykillian@gmail.com
henriclaudejacques@yahoo.com
brettdrumer4him@aol.com
cutiepie0200@gmail.com
atlandreth@gmail.com
ricardo.silva@sbcglobal.net
james11419@yahoo.com
yuli.nene@yahoo.es
ladykanzky@yahoo.com
jgula@uswest.net
bobhjr77@gmail.com
rojasmildrey.rz@gmail.com
blarusso@yahoo.com
bellaitalia27@gmail.com
mattwilson4t@gmail.com
sanchezzelaya.jz@gmail.com
nickysantos0222@gmail.com
mapp2ale@gmail.com
helenmun@gmail.com
brandon@nbcontracting.com
1twoblue1@gmail.com
jason.ehlert@yahoo.com
dailybangerz1@gmail.com
phurley@peopleinc.net
frank.zellers@exprealty.com
asargsyan077@gmail.com
larhondrawilliams@gmail.com
cwolson01@aol.com
odl55@gmail.com
dimabelonog@aol.com
lmperformance@yahoo.com
jennifertice81@yahoo.com
farouksharma@gmail.com
tmikeladze@me.com
angel_brunson@yahoo.com
energydirect@live.com
ewn91@aol.com
jussaracamilo10@yahoo.com
peteravon40@gmail.com
alexander.valdez36165@gmail.com

---

## HOW TO SEND

1. Open Gmail
2. Create new draft with the email body above
3. Click **BCC** field (not TO)
4. Paste ALL 600 emails from both lists above
5. Review subject line
6. Click **SEND**

**That's it. One email. 600 recipients. Both options covered.**

---

## WHY THIS WORKS

✅ Doesn't assume their situation  
✅ Opens doors for both scenarios  
✅ They choose what applies to them  
✅ Reduces objection ("I don't need funding")  
✅ Higher response rate (both angles = wider net)  
✅ Simplifies your call script  

---

## WHAT HAPPENS AFTER

**Tomorrow when you call:**

**If they say: "I don't need funding"**  
You respond: "No problem. How about lower rates on what you have?"

**If they say: "I'm already funded"**  
You respond: "Perfect. Can we lower that payment 30-40%?"

**If they say: "I need funding"**  
You respond: "Great. Let's get you approved today."

**One email. One call script. All scenarios covered.**

